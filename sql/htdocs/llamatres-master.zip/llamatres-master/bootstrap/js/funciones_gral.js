  
   function cargar(div,desde)
   {
   $(div).load(desde);
   } 
   
   
   function poner_nombre(div,nombre)
   {
   $(div).text(nombre);
   } 

  
   
