<?php

include("menu_bs.php");

include_once("libreria/carteles.php");

$cats=Cartel::categorias();

echo '
<div class="container-fluid">
<div class="row">
<div class="col-sm-4">
<div id="capa_d">
	<H3>BIBLIOTECA T1</H3>
	<H4>Ayuda</H4>
';

foreach($cats as $cat){
echo '
<ul class="nav nav-pills nav-stacked">
<li>
<a href="#"><span onclick="cargar(\'#capa_C\',\'mostrar_cartelera.php?b='.$cat['categoria'].'\')">'.$cat['categoria'].'</span></a
</ul>
';
}	  
	   
echo '

</div>
</div>
<div class="col-sm-8">
<div id="capa_C">	
</div>
</div>	
</div>
</div>

';
echo "<script>";
echo "cargar('#capa_C','mostrar_cartelera.php?b=Ayuda');";
echo "</script>";
?>
